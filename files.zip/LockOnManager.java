package com.lockonmod.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;

public class LockOnManager {

    private static final LockOnManager INSTANCE = new LockOnManager();

    // Settings
    private boolean lockOnEnabled = false;
    private float reachDistance = 6.0f;   // default vanilla-ish; configurable up to 20
    private boolean lockOnMobs = true;
    private boolean lockOnPlayers = false;
    private boolean showIndicator = true;

    // State
    private Entity lockedTarget = null;
    private boolean isLockedOn = false;

    public static LockOnManager getInstance() {
        return INSTANCE;
    }

    // -----------------------------------------------------------------------
    // Toggle lock-on: find nearest valid entity in front of the player
    // -----------------------------------------------------------------------
    public void toggleLockOn(MinecraftClient client) {
        if (!lockOnEnabled) return;
        if (client.player == null || client.world == null) return;

        if (isLockedOn) {
            unlock();
            return;
        }

        Entity target = findBestTarget(client);
        if (target != null) {
            lockedTarget = target;
            isLockedOn = true;
        }
    }

    public void unlock() {
        lockedTarget = null;
        isLockedOn = false;
    }

    // -----------------------------------------------------------------------
    // Each tick: if locked on, rotate camera toward target
    // -----------------------------------------------------------------------
    public void tick(MinecraftClient client) {
        if (!lockOnEnabled || !isLockedOn || lockedTarget == null || client.player == null) return;

        // Clear lock if target is dead or gone
        if (!lockedTarget.isAlive() || lockedTarget.isRemoved()) {
            unlock();
            return;
        }

        // Clear lock if target is now out of reach range (2x reach as safety margin)
        double dist = client.player.distanceTo(lockedTarget);
        if (dist > reachDistance * 2.5) {
            unlock();
            return;
        }

        // Smoothly aim the camera at the target
        aimAtEntity(client.player, lockedTarget);
    }

    // -----------------------------------------------------------------------
    // Rotate player yaw/pitch toward the locked entity's center
    // -----------------------------------------------------------------------
    private void aimAtEntity(PlayerEntity player, Entity target) {
        Vec3d playerEyes = player.getEyePos();
        Vec3d targetCenter = target.getPos().add(0, target.getHeight() * 0.5, 0);

        double dx = targetCenter.x - playerEyes.x;
        double dy = targetCenter.y - playerEyes.y;
        double dz = targetCenter.z - playerEyes.z;

        double horizontalDist = Math.sqrt(dx * dx + dz * dz);

        float targetYaw   = (float)(Math.toDegrees(Math.atan2(-dx, dz)));
        float targetPitch = (float)(Math.toDegrees(-Math.atan2(dy, horizontalDist)));

        // Smooth lerp (10% per tick feels fluid)
        float lerpFactor = 0.15f;
        float currentYaw   = player.getYaw();
        float currentPitch = player.getPitch();

        // Normalise yaw delta to [-180, 180] to avoid spinning
        float yawDelta = targetYaw - currentYaw;
        while (yawDelta > 180)  yawDelta -= 360;
        while (yawDelta < -180) yawDelta += 360;

        float newYaw   = currentYaw   + yawDelta * lerpFactor;
        float newPitch = currentPitch + (targetPitch - currentPitch) * lerpFactor;
        newPitch = Math.max(-90, Math.min(90, newPitch));

        player.setYaw(newYaw);
        player.setPitch(newPitch);
    }

    // -----------------------------------------------------------------------
    // Find the entity closest to the player's crosshair within reach range
    // -----------------------------------------------------------------------
    private Entity findBestTarget(MinecraftClient client) {
        PlayerEntity player = client.player;
        if (player == null || client.world == null) return null;

        Vec3d eyePos = player.getEyePos();
        Vec3d lookVec = player.getRotationVec(1.0f);
        double searchRange = reachDistance;

        Box searchBox = player.getBoundingBox()
                .expand(searchRange, searchRange, searchRange);

        List<Entity> candidates = client.world.getEntitiesByClass(
                LivingEntity.class, searchBox,
                entity -> isValidTarget(entity, player)
        );

        // Score by angle to crosshair (prefer entities directly in front)
        return candidates.stream()
                .min(Comparator.comparingDouble(entity -> {
                    Vec3d toEntity = entity.getPos()
                            .add(0, entity.getHeight() * 0.5, 0)
                            .subtract(eyePos)
                            .normalize();
                    // Dot product: 1 = directly in front, -1 = directly behind
                    double dot = lookVec.dotProduct(toEntity);
                    return -dot; // minimise negative dot = maximise dot
                }))
                .filter(entity -> {
                    // Only lock on if it's within a 90° cone in front of player
                    Vec3d toEntity = entity.getPos()
                            .add(0, entity.getHeight() * 0.5, 0)
                            .subtract(eyePos)
                            .normalize();
                    return lookVec.dotProduct(toEntity) > 0.5;
                })
                .orElse(null);
    }

    private boolean isValidTarget(Entity entity, PlayerEntity player) {
        if (entity == player) return false;
        if (!entity.isAlive()) return false;
        if (entity instanceof PlayerEntity && !lockOnPlayers) return false;
        if (!(entity instanceof PlayerEntity) && !lockOnMobs) return false;
        double dist = player.distanceTo(entity);
        return dist <= reachDistance;
    }

    // -----------------------------------------------------------------------
    // Getters / setters used by the GUI
    // -----------------------------------------------------------------------
    public boolean isLockOnEnabled()             { return lockOnEnabled; }
    public void setLockOnEnabled(boolean v)      { lockOnEnabled = v; if (!v) unlock(); }

    public float getReachDistance()              { return reachDistance; }
    public void setReachDistance(float v)        { reachDistance = Math.max(3f, Math.min(20f, v)); }

    public boolean isLockOnMobs()                { return lockOnMobs; }
    public void setLockOnMobs(boolean v)         { lockOnMobs = v; }

    public boolean isLockOnPlayers()             { return lockOnPlayers; }
    public void setLockOnPlayers(boolean v)      { lockOnPlayers = v; }

    public boolean isShowIndicator()             { return showIndicator; }
    public void setShowIndicator(boolean v)      { showIndicator = v; }

    public boolean isLockedOn()                  { return isLockedOn; }
    public Entity getLockedTarget()              { return lockedTarget; }
}
