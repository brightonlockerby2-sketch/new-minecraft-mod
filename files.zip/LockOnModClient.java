package com.lockonmod;

import com.lockonmod.client.LockOnHudRenderer;
import com.lockonmod.client.LockOnManager;
import com.lockonmod.client.gui.LockOnScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class LockOnModClient implements ClientModInitializer {

    public static KeyBinding openMenuKey;
    public static KeyBinding lockOnKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lockonmod.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                "category.lockonmod.keys"
        ));

        lockOnKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lockonmod.lock_on",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.lockonmod.keys"
        ));

        // Register HUD overlay
        HudRenderCallback.EVENT.register(new LockOnHudRenderer());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new LockOnScreen());
                }
            }
            while (lockOnKey.wasPressed()) {
                LockOnManager.getInstance().toggleLockOn(client);
            }
            LockOnManager.getInstance().tick(client);
        });
    }
}
