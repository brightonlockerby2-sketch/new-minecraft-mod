package com.lockonmod;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LockOnMod implements ModInitializer {
    public static final String MOD_ID = "lockonmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("LockOn Mod initialized!");
    }
}
