package com.lockonmod.mixin;

import com.lockonmod.client.LockOnManager;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public class ReachDistanceMixin {

    @Inject(method = "getReachDistance", at = @At("RETURN"), cancellable = true)
    private void overrideReachDistance(CallbackInfoReturnable<Float> cir) {
        LockOnManager mgr = LockOnManager.getInstance();
        if (mgr.isLockOnEnabled()) {
            cir.setReturnValue(mgr.getReachDistance());
        }
    }

    @Inject(method = "hasExtendedReach", at = @At("RETURN"), cancellable = true)
    private void overrideExtendedReach(CallbackInfoReturnable<Boolean> cir) {
        if (LockOnManager.getInstance().isLockOnEnabled()) {
            cir.setReturnValue(true);
        }
    }
}
