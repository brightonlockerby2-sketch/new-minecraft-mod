package com.lockonmod.client;

import com.lockonmod.LockOnMod;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

public class LockOnHudRenderer implements HudRenderCallback {

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        LockOnManager mgr = LockOnManager.getInstance();

        if (!mgr.isLockOnEnabled() || !mgr.isShowIndicator()) return;
        if (!mgr.isLockedOn() || mgr.getLockedTarget() == null) return;

        Entity target = mgr.getLockedTarget();
        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();

        // Draw a simple bracket indicator in the center of the HUD
        int cx = screenW / 2;
        int cy = screenH / 2;

        int size = 12;
        int thickness = 2;
        int color = 0xFFFF4444; // red

        // Top-left bracket
        context.fill(cx - size, cy - size, cx - size + size/2, cy - size + thickness, color);
        context.fill(cx - size, cy - size, cx - size + thickness, cy - size + size/2, color);

        // Top-right bracket
        context.fill(cx + size - size/2, cy - size, cx + size, cy - size + thickness, color);
        context.fill(cx + size - thickness, cy - size, cx + size, cy - size + size/2, color);

        // Bottom-left bracket
        context.fill(cx - size, cy + size - thickness, cx - size + size/2, cy + size, color);
        context.fill(cx - size, cy + size - size/2, cx - size + thickness, cy + size, color);

        // Bottom-right bracket
        context.fill(cx + size - size/2, cy + size - thickness, cx + size, cy + size, color);
        context.fill(cx + size - thickness, cy + size - size/2, cx + size, cy + size, color);

        // Target name + distance
        if (client.player != null) {
            String name = target.getName().getString();
            double dist = client.player.distanceTo(target);
            String label = name + " §7(" + String.format("%.1f", dist) + "m)";
            int textW = client.textRenderer.getWidth(label);
            context.drawTextWithShadow(client.textRenderer, label, cx - textW / 2, cy - size - 14, 0xFFFF6666);
        }
    }
}
