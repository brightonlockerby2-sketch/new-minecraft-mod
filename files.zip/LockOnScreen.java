package com.lockonmod.client.gui;

import com.lockonmod.client.LockOnManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class LockOnScreen extends Screen {

    private static final int PANEL_W = 280;
    private static final int PANEL_H = 280;
    private static final int BG_COLOR  = 0xCC1A1A2E;
    private static final int HDR_COLOR = 0xFF16213E;
    private static final int ACCENT    = 0xFFE94560;
    private static final int TEXT_COLOR = 0xFFEEEEEE;
    private static final int BTN_H = 22;

    private final LockOnManager mgr = LockOnManager.getInstance();

    public LockOnScreen() {
        super(Text.of("LockOn Settings"));
    }

    @Override
    protected void init() {
        int panelX = (this.width  - PANEL_W) / 2;
        int panelY = (this.height - PANEL_H) / 2;
        int btnX   = panelX + 20;
        int btnW   = PANEL_W - 40;

        int y = panelY + 55;

        // ── Enable Lock-On toggle ──
        addToggleButton(btnX, y, btnW, "Lock-On Enabled", mgr.isLockOnEnabled(),
                val -> mgr.setLockOnEnabled(val));
        y += BTN_H + 8;

        // ── Lock on Mobs toggle ──
        addToggleButton(btnX, y, btnW, "Target Mobs", mgr.isLockOnMobs(),
                val -> mgr.setLockOnMobs(val));
        y += BTN_H + 8;

        // ── Lock on Players toggle ──
        addToggleButton(btnX, y, btnW, "Target Players", mgr.isLockOnPlayers(),
                val -> mgr.setLockOnPlayers(val));
        y += BTN_H + 8;

        // ── Show Indicator toggle ──
        addToggleButton(btnX, y, btnW, "Show HUD Indicator", mgr.isShowIndicator(),
                val -> mgr.setShowIndicator(val));
        y += BTN_H + 8;

        // ── Reach distance slider ──
        int sliderY = y;
        addDrawableChild(new SliderWidget(btnX, sliderY, btnW, BTN_H,
                Text.of("Reach: " + String.format("%.1f", mgr.getReachDistance()) + " blocks"),
                (mgr.getReachDistance() - 3f) / 17f) {
            @Override
            protected void updateMessage() {
                float val = 3f + (float) value * 17f;
                setMessage(Text.of("Reach: " + String.format("%.1f", val) + " blocks"));
            }
            @Override
            protected void applyValue() {
                float val = 3f + (float) value * 17f;
                mgr.setReachDistance(val);
            }
        });
        y += BTN_H + 16;

        // ── Close button ──
        addDrawableChild(ButtonWidget.builder(Text.of("Close"), btn -> this.close())
                .dimensions(btnX, y, btnW, BTN_H)
                .build());
    }

    private void addToggleButton(int x, int y, int w, String label, boolean current,
                                  java.util.function.Consumer<Boolean> setter) {
        final boolean[] state = {current};
        ButtonWidget btn = ButtonWidget.builder(
                Text.of(label + ": " + (state[0] ? "§aON" : "§cOFF")),
                b -> {
                    state[0] = !state[0];
                    setter.accept(state[0]);
                    b.setMessage(Text.of(label + ": " + (state[0] ? "§aON" : "§cOFF")));
                })
                .dimensions(x, y, w, BTN_H)
                .build();
        addDrawableChild(btn);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Dim background
        renderBackground(ctx, mouseX, mouseY, delta);

        int panelX = (this.width  - PANEL_W) / 2;
        int panelY = (this.height - PANEL_H) / 2;

        // Panel background
        ctx.fill(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H, BG_COLOR);

        // Header bar
        ctx.fill(panelX, panelY, panelX + PANEL_W, panelY + 40, HDR_COLOR);

        // Accent stripe
        ctx.fill(panelX, panelY + 38, panelX + PANEL_W, panelY + 41, ACCENT);

        // Title
        String title = "⚔  LockOn & Reach  ⚔";
        int titleW = this.textRenderer.getWidth(title);
        ctx.drawTextWithShadow(this.textRenderer, title,
                panelX + (PANEL_W - titleW) / 2, panelY + 14, ACCENT);

        // Subtitle / keybind hint
        String hint = "R = lock/unlock  |  K = this menu";
        int hintW = this.textRenderer.getWidth(hint);
        ctx.drawTextWithShadow(this.textRenderer, "§7" + hint,
                panelX + (PANEL_W - hintW) / 2, panelY + 44, TEXT_COLOR);

        // Draw reach label above slider area
        ctx.drawTextWithShadow(this.textRenderer, "§7Drag slider to change reach distance (3 – 20):",
                panelX + 20, panelY + 185, 0xFFAAAAAA);

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false; // keep game running while menu is open
    }
}
